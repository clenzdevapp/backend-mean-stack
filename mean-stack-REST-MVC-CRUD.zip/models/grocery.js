const db = require('../util/database');

module.exports = class Grocery {
  constructor(id, item) {
    this.id = id;
    this.item = item;
  }

  /**
   * CLE: Select-Statement gegen die DB-Verbindung MySQL
   */
  //READ
  static fetchAll() {
    return db.execute("SELECT * FROM groceries");
  }

  //CREATE
  static post(item){
    return db.execute("INSERT INTO groceries (item) VALUES (?)", [item] );
  }

  //UPDATE
  static update(id, item){
    return db.execute("UPDATE groceries SET item = ? WHERE id = ?", [item, id] );
  }

  //DELETE
  static delete(id){
    return db.execute("DELETE FROM groceries WHERE id = ?", [id]);
  }
};
