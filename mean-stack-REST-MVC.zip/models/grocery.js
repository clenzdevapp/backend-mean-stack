const db = require('../util/database');

module.exports = class Grocery {
  constructor(id, item) {
    this.id = id;
    this.item = item;
  }

  /**
   * CLE: Select-Statement gegen die DB-Verbindung MySQL
   */
  static fetchAll() {
    return db.execute("SELECT * FROM groceries");
  }
};
